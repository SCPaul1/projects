import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});
  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  String _dept = 'All';
  String _search = '';
  final _depts = ['All', 'Engineering', 'Design', 'Analytics', 'Sales', 'Marketing', 'HR'];

  final _employees = const [
    _Employee('Jordan Lee', 'Data Analyst', 'Analytics', 'Full-time', 'Active', '🇨🇦', '3y 2m', 'jlee@acme.com', '\$95K', 'Team A'),
    _Employee('Maria Chen', 'Sr. Software Engineer', 'Engineering', 'Full-time', 'Active', '🇺🇸', '5y 1m', 'mchen@acme.com', '\$155K', 'Platform'),
    _Employee('Chris Patel', 'Product Designer', 'Design', 'Full-time', 'Active', '🇮🇳', '2y 8m', 'cpatel@acme.com', '\$120K', 'Mobile'),
    _Employee('Alex Kim', 'UX Researcher', 'Design', 'Contract', 'Active', '🇯🇵', '1y 4m', 'akim@acme.com', '\$85K', 'Growth'),
    _Employee('Sam Rivera', 'DevOps Engineer', 'Engineering', 'Full-time', 'On Leave', '🇲🇽', '4y 0m', 'srivera@acme.com', '\$140K', 'Infra'),
    _Employee('Aisha Noor', 'HR Manager', 'HR', 'Full-time', 'Active', '🇬🇧', '6y 5m', 'anoor@acme.com', '\$105K', 'People Ops'),
    _Employee('Taylor Wu', 'Sales Executive', 'Sales', 'Full-time', 'Active', '🇨🇳', '2y 2m', 'twu@acme.com', '\$80K + OTE', 'Enterprise'),
    _Employee('Priya Singh', 'ML Engineer', 'Engineering', 'Full-time', 'Active', '🇮🇳', '1y 9m', 'psingh@acme.com', '\$165K', 'AI Team'),
    _Employee('Lena Müller', 'Marketing Lead', 'Marketing', 'Full-time', 'Active', '🇩🇪', '3y 6m', 'lmuller@acme.com', '\$110K', 'Brand'),
    _Employee('James Park', 'Graphic Designer', 'Design', 'Part-time', 'Active', '🇰🇷', '0y 8m', 'jpark@acme.com', '\$65K', 'Brand'),
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = _employees.where((e) {
      final matchDept = _dept == 'All' || e.dept == _dept;
      final matchSearch = _search.isEmpty || e.name.toLowerCase().contains(_search.toLowerCase()) || e.role.toLowerCase().contains(_search.toLowerCase());
      return matchDept && matchSearch;
    }).toList();

    final active = filtered.where((e) => e.status == 'Active').length;
    final onLeave = filtered.where((e) => e.status == 'On Leave').length;

    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          PageHeader(
            title: 'Employees',
            subtitle: '${_employees.length} total · $active active · $onLeave on leave',
            action: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.person_add_outlined, size: 16),
              label: const Text('Add Employee'),
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentAlt, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Dept summary cards
                  Row(children: [
                    _DeptStat('Engineering', 3, AppTheme.accent),
                    const SizedBox(width: 12),
                    _DeptStat('Design', 3, const Color(0xFF9B59B6)),
                    const SizedBox(width: 12),
                    _DeptStat('Analytics', 1, AppTheme.accentAlt),
                    const SizedBox(width: 12),
                    _DeptStat('Sales', 1, AppTheme.warning),
                    const SizedBox(width: 12),
                    _DeptStat('HR & Marketing', 2, AppTheme.danger),
                  ]),
                  const SizedBox(height: 20),
                  // Filters + search
                  Row(children: [
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: _depts.map((d) {
                            final active = _dept == d;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: InkWell(
                                onTap: () => setState(() => _dept = d),
                                borderRadius: BorderRadius.circular(20),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: active ? AppTheme.accent : AppTheme.card,
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(color: active ? AppTheme.accent : AppTheme.cardBorder),
                                  ),
                                  child: Text(d, style: TextStyle(color: active ? Colors.white : AppTheme.textSecondary, fontSize: 13, fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    SizedBox(
                      width: 220, height: 38,
                      child: TextField(
                        onChanged: (v) => setState(() => _search = v),
                        style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
                        decoration: InputDecoration(
                          hintText: 'Search employees…',
                          prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted, size: 16),
                          contentPadding: const EdgeInsets.symmetric(vertical: 0),
                          filled: true, fillColor: AppTheme.card,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.cardBorder)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.cardBorder)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.accent)),
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  Expanded(
                    child: SectionCard(
                      title: '${filtered.length} employees',
                      child: Column(
                        children: [
                          _headerRow(),
                          const Divider(color: AppTheme.cardBorder, height: 1),
                          Expanded(
                            child: ListView.separated(
                              itemCount: filtered.length,
                              separatorBuilder: (_, __) => const Divider(color: AppTheme.cardBorder, height: 1),
                              itemBuilder: (_, i) => _dataRow(filtered[i]),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _headerRow() {
    const style = TextStyle(color: AppTheme.textMuted, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(children: const [
        Expanded(flex: 3, child: Text('EMPLOYEE', style: style)),
        Expanded(flex: 2, child: Text('ROLE', style: style)),
        Expanded(flex: 2, child: Text('DEPARTMENT', style: style)),
        Expanded(flex: 2, child: Text('TEAM / SALARY', style: style)),
        Expanded(child: Text('TYPE', style: style)),
        Expanded(child: Text('TENURE', style: style)),
        Expanded(child: Text('STATUS', style: style)),
        SizedBox(width: 40),
      ]),
    );
  }

  Widget _dataRow(_Employee e) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(children: [
        Expanded(flex: 3, child: Row(children: [
          Text(e.flag, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(e.name, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
            Text(e.email, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
          ]),
        ])),
        Expanded(flex: 2, child: Text(e.role, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
        Expanded(flex: 2, child: Text(e.dept, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
        Expanded(flex: 2, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(e.team, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          Text(e.salary, style: const TextStyle(color: AppTheme.accentAlt, fontSize: 12, fontWeight: FontWeight.w600)),
        ])),
        Expanded(child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
          decoration: BoxDecoration(
            color: e.type == 'Contract' ? AppTheme.warning.withOpacity(0.12) : e.type == 'Part-time' ? const Color(0xFF9B59B6).withOpacity(0.12) : AppTheme.accent.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(e.type, style: TextStyle(
            color: e.type == 'Contract' ? AppTheme.warning : e.type == 'Part-time' ? const Color(0xFF9B59B6) : AppTheme.accent,
            fontSize: 11, fontWeight: FontWeight.w600,
          )),
        )),
        Expanded(child: Text(e.tenure, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
        Expanded(child: Row(children: [
          Container(width: 7, height: 7, decoration: BoxDecoration(
            color: e.status == 'Active' ? AppTheme.accentAlt : AppTheme.warning,
            shape: BoxShape.circle,
          )),
          const SizedBox(width: 6),
          Text(e.status, style: TextStyle(color: e.status == 'Active' ? AppTheme.accentAlt : AppTheme.warning, fontSize: 12)),
        ])),
        SizedBox(width: 40, child: IconButton(icon: const Icon(Icons.more_horiz, color: AppTheme.textMuted, size: 16), onPressed: () {})),
      ]),
    );
  }
}

class _DeptStat extends StatelessWidget {
  final String dept;
  final int count;
  final Color color;
  const _DeptStat(this.dept, this.count, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.2))),
    child: Row(children: [
      Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 8),
      Text(dept, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w500)),
      const SizedBox(width: 6),
      Text('$count', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
    ]),
  );
}

class _Employee {
  final String name, role, dept, type, status, flag, tenure, email, salary, team;
  const _Employee(this.name, this.role, this.dept, this.type, this.status, this.flag, this.tenure, this.email, this.salary, this.team);
}
