import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class DirectoryScreen extends StatelessWidget {
  const DirectoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Employee Directory',
            subtitle: 'Find your colleagues',
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search by name, department, or role...',
                        prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted, size: 20),
                        filled: true,
                        fillColor: AppTheme.card,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  SectionCard(
                    title: 'Engineering',
                    child: Column(
                      children: _employees
                          .where((e) => e.department == 'Engineering')
                          .map((e) => _EmployeeRow(employee: e))
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Design',
                    child: Column(
                      children: _employees
                          .where((e) => e.department == 'Design')
                          .map((e) => _EmployeeRow(employee: e))
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Product',
                    child: Column(
                      children: _employees
                          .where((e) => e.department == 'Product')
                          .map((e) => _EmployeeRow(employee: e))
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmployeeRow extends StatelessWidget {
  final _Employee employee;

  const _EmployeeRow({required this.employee});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: employee.color.withOpacity(0.2),
              child: Text(
                employee.initials,
                style: TextStyle(color: employee.color, fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    employee.name,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '${employee.role} · ${employee.department}',
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.email_outlined, color: AppTheme.accent, size: 18),
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _Employee {
  final String name;
  final String initials;
  final String role;
  final String department;
  final Color color;

  const _Employee(this.name, this.initials, this.role, this.department, this.color);
}

const _employees = [
  _Employee('Sarah Chen', 'SC', 'Engineering Manager', 'Engineering', AppTheme.accent),
  _Employee('Saroj Paul', 'SP', 'Software Engineer', 'Engineering', AppTheme.accentAlt),
  _Employee('Jordan Lee', 'JL', 'DevOps Engineer', 'Engineering', AppTheme.warning),
  _Employee('Maria Garcia', 'MG', 'Product Designer', 'Design', AppTheme.accent),
  _Employee('Taylor Wu', 'TW', 'UX Researcher', 'Design', AppTheme.accentAlt),
  _Employee('Chris Evans', 'CE', 'Product Manager', 'Product', AppTheme.warning),
];
