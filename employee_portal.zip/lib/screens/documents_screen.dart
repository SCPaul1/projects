import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class DocumentsScreen extends StatelessWidget {
  const DocumentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Documents',
            subtitle: 'Payslips and company documents',
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SectionCard(
                    title: 'Payslips',
                    child: Column(
                      children: _payslips.map((p) => _DocumentRow(doc: p)).toList(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Tax Forms',
                    child: Column(
                      children: _taxForms.map((t) => _DocumentRow(doc: t)).toList(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Policy Documents',
                    child: Column(
                      children: _policies.map((p) => _DocumentRow(doc: p)).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DocumentRow extends StatelessWidget {
  final _Document doc;

  const _DocumentRow({required this.doc});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: doc.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(doc.icon, color: doc.color, size: 22),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    doc.title,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (doc.subtitle != null)
                    Text(
                      doc.subtitle!,
                      style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                    ),
                ],
              ),
            ),
            Text(
              doc.date,
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
            ),
            const SizedBox(width: 12),
            IconButton(
              icon: const Icon(Icons.download_outlined, color: AppTheme.accent, size: 20),
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _Document {
  final String title;
  final String? subtitle;
  final String date;
  final IconData icon;
  final Color color;

  const _Document(this.title, this.subtitle, this.date, this.icon, this.color);
}

const _payslips = [
  _Document('Payslip - March 2026', 'Net: \$4,850.00', '21 Mar 2026', Icons.receipt_long_outlined, AppTheme.accent),
  _Document('Payslip - February 2026', 'Net: \$4,850.00', '21 Feb 2026', Icons.receipt_long_outlined, AppTheme.accent),
  _Document('Payslip - January 2026', 'Net: \$4,850.00', '21 Jan 2026', Icons.receipt_long_outlined, AppTheme.accent),
  _Document('Payslip - December 2025', 'Net: \$5,200.00', '21 Dec 2025', Icons.receipt_long_outlined, AppTheme.accent),
];

const _taxForms = [
  _Document('W-2 2025', 'Annual earnings summary', '31 Jan 2026', Icons.description_outlined, AppTheme.accentAlt),
  _Document('W-2 2024', 'Annual earnings summary', '31 Jan 2025', Icons.description_outlined, AppTheme.accentAlt),
];

const _policies = [
  _Document('Employee Handbook 2026', null, '01 Jan 2026', Icons.menu_book_outlined, AppTheme.warning),
  _Document('Benefits Guide', null, '15 Dec 2025', Icons.medical_services_outlined, AppTheme.accentAlt),
  _Document('Leave Policy', null, '01 Jan 2025', Icons.calendar_month_outlined, AppTheme.accent),
];
