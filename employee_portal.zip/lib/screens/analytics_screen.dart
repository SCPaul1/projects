import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';
import '../widgets/stat_card.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Analytics',
            subtitle: 'Last 30 days · All departments',
            action: _ExportBtn(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // KPI row
                  GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1.6,
                    children: const [
                      StatCard(label: 'Applications', value: '1,284', delta: '+18%', positive: true, icon: Icons.inbox_outlined, color: AppTheme.accent),
                      StatCard(label: 'Time to Hire', value: '18d', delta: '-3d', positive: true, icon: Icons.timer_outlined, color: AppTheme.accentAlt),
                      StatCard(label: 'Offer Accept Rate', value: '84%', delta: '+5%', positive: true, icon: Icons.thumb_up_outlined, color: AppTheme.warning),
                      StatCard(label: 'Cost per Hire', value: '\$4.2K', delta: '-\$600', positive: true, icon: Icons.attach_money, color: AppTheme.danger),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Charts row 1
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 3,
                        child: SectionCard(
                          title: 'Applications Over Time (Mar)',
                          child: SizedBox(
                            height: 220,
                            child: CustomPaint(painter: _AreaChartPainter(), child: const SizedBox.expand()),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 2,
                        child: SectionCard(
                          title: 'Source of Hire',
                          child: SizedBox(
                            height: 220,
                            child: Row(children: [
                              Expanded(child: CustomPaint(painter: _DonutPainter(), child: const SizedBox.expand())),
                              const SizedBox(width: 16),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: const [
                                  _Legend('LinkedIn', AppTheme.accent, '42%', 540),
                                  _Legend('Referral', AppTheme.accentAlt, '28%', 360),
                                  _Legend('Indeed', AppTheme.warning, '18%', 231),
                                  _Legend('Other', AppTheme.textMuted, '12%', 153),
                                ],
                              ),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Charts row 2
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: SectionCard(
                          title: 'Hires by Department (Q1 2026)',
                          child: SizedBox(
                            height: 200,
                            child: CustomPaint(painter: _BarChartPainter(), child: const SizedBox.expand()),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: SectionCard(
                          title: 'Time-to-Hire by Role',
                          child: SizedBox(
                            height: 200,
                            child: CustomPaint(painter: _HBarChartPainter(), child: const SizedBox.expand()),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Metrics row
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: SectionCard(
                          title: 'Funnel Conversion Rates',
                          child: Column(children: const [
                            _FunnelRow('Applied → Screened', 1284, 342, AppTheme.accent),
                            _FunnelRow('Screened → Interview', 342, 89, AppTheme.warning),
                            _FunnelRow('Interview → Offer', 89, 14, Color(0xFF9B59B6)),
                            _FunnelRow('Offer → Hired', 14, 12, AppTheme.accentAlt),
                          ]),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: SectionCard(
                          title: 'Key Metrics',
                          child: Column(children: const [
                            _MetricRow('Interview-to-Offer Rate', '67%', AppTheme.accent),
                            _MetricRow('Rejection Rate', '34%', AppTheme.danger),
                            _MetricRow('Screening Pass Rate', '27%', AppTheme.accentAlt),
                            _MetricRow('Avg. Applications / Role', '53', AppTheme.warning),
                            _MetricRow('Diversity Hire Rate', '41%', Color(0xFF9B59B6)),
                            _MetricRow('30-day Retention', '96%', AppTheme.accentAlt),
                          ]),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: SectionCard(
                          title: 'Department Headcount',
                          child: Column(
                            children: const [
                              _HeadcountRow('Engineering', 84, AppTheme.accent),
                              _HeadcountRow('Design', 28, Color(0xFF9B59B6)),
                              _HeadcountRow('Analytics', 19, AppTheme.accentAlt),
                              _HeadcountRow('Sales', 36, AppTheme.warning),
                              _HeadcountRow('Marketing', 22, AppTheme.danger),
                              _HeadcountRow('HR & Ops', 18, AppTheme.textSecondary),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Widgets ──

class _ExportBtn extends StatelessWidget {
  const _ExportBtn();
  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
    onPressed: () {},
    icon: const Icon(Icons.download_outlined, size: 16, color: AppTheme.textSecondary),
    label: const Text('Export CSV', style: TextStyle(color: AppTheme.textSecondary)),
    style: OutlinedButton.styleFrom(side: const BorderSide(color: AppTheme.cardBorder), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
  );
}

class _Legend extends StatelessWidget {
  final String label, percent;
  final Color color;
  final int count;
  const _Legend(this.label, this.color, this.percent, this.count);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 8),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
        Row(children: [
          Text(percent, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(width: 4),
          Text('($count)', style: const TextStyle(color: AppTheme.textMuted, fontSize: 10)),
        ]),
      ]),
    ]),
  );
}

class _MetricRow extends StatelessWidget {
  final String label, value;
  final Color color;
  const _MetricRow(this.label, this.value, this.color);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
        child: Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w700)),
      ),
    ]),
  );
}

class _FunnelRow extends StatelessWidget {
  final String label;
  final int from, to;
  final Color color;
  const _FunnelRow(this.label, this.from, this.to, this.color);
  @override
  Widget build(BuildContext context) {
    final pct = to / from;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          Text('$to / $from  (${(pct * 100).round()}%)', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 6),
        LinearProgressIndicator(value: pct, backgroundColor: AppTheme.cardBorder, valueColor: AlwaysStoppedAnimation(color), minHeight: 5, borderRadius: BorderRadius.circular(3)),
      ]),
    );
  }
}

class _HeadcountRow extends StatelessWidget {
  final String dept;
  final int count;
  final Color color;
  const _HeadcountRow(this.dept, this.count, this.color);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(children: [
      Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 10),
      Expanded(child: Text(dept, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
      Text('$count', style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
      const SizedBox(width: 10),
      SizedBox(
        width: 80,
        child: LinearProgressIndicator(value: count / 100, backgroundColor: AppTheme.cardBorder, valueColor: AlwaysStoppedAnimation(color), minHeight: 4, borderRadius: BorderRadius.circular(2)),
      ),
    ]),
  );
}

// ── Custom Painters ──

class _AreaChartPainter extends CustomPainter {
  final _data = const [42, 68, 55, 91, 78, 115, 99, 138, 112, 162, 141, 178, 154, 195, 172, 214, 199, 231, 212, 248, 234, 265, 253, 283, 271, 298, 279, 314, 293, 331];
  final _labels = const ['Mar 1', 'Mar 8', 'Mar 15', 'Mar 22', 'Mar 29'];

  @override
  void paint(Canvas canvas, Size size) {
    final bPad = 28.0, lPad = 44.0;
    final chartH = size.height - bPad, chartW = size.width - lPad;
    final maxVal = _data.reduce(max).toDouble();

    // Grid
    final gridPaint = Paint()..color = AppTheme.cardBorder..strokeWidth = 1;
    final tp = TextPainter(textDirection: TextDirection.ltr);
    for (int i = 0; i <= 4; i++) {
      final y = chartH - (i / 4) * chartH;
      canvas.drawLine(Offset(lPad, y), Offset(size.width, y), gridPaint);
      tp.text = TextSpan(text: '${(maxVal * i / 4).round()}', style: const TextStyle(color: AppTheme.textMuted, fontSize: 10));
      tp.layout();
      tp.paint(canvas, Offset(lPad - tp.width - 6, y - tp.height / 2));
    }

    // Fill
    final fillPath = Path();
    for (int i = 0; i < _data.length; i++) {
      final x = lPad + i * chartW / (_data.length - 1);
      final y = chartH - (_data[i] / maxVal) * chartH * 0.9;
      if (i == 0) { fillPath.moveTo(x, chartH); fillPath.lineTo(x, y); }
      else fillPath.lineTo(x, y);
    }
    fillPath.lineTo(lPad + chartW, chartH);
    fillPath.close();
    canvas.drawPath(fillPath, Paint()
      ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [AppTheme.accent.withOpacity(0.3), AppTheme.accent.withOpacity(0.0)])
          .createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill);

    // Line
    final linePath = Path();
    for (int i = 0; i < _data.length; i++) {
      final x = lPad + i * chartW / (_data.length - 1);
      final y = chartH - (_data[i] / maxVal) * chartH * 0.9;
      i == 0 ? linePath.moveTo(x, y) : linePath.lineTo(x, y);
    }
    canvas.drawPath(linePath, Paint()..color = AppTheme.accent..strokeWidth = 2..style = PaintingStyle.stroke..strokeJoin = StrokeJoin.round);

    // Endpoint dot
    final lx = lPad + chartW;
    final ly = chartH - (_data.last / maxVal) * chartH * 0.9;
    canvas.drawCircle(Offset(lx, ly), 5, Paint()..color = AppTheme.accent);
    canvas.drawCircle(Offset(lx, ly), 3, Paint()..color = AppTheme.surface);

    // X labels
    for (int i = 0; i < _labels.length; i++) {
      final x = lPad + i * chartW / (_labels.length - 1);
      tp.text = TextSpan(text: _labels[i], style: const TextStyle(color: AppTheme.textMuted, fontSize: 10));
      tp.layout();
      tp.paint(canvas, Offset(x - tp.width / 2, chartH + 8));
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _DonutPainter extends CustomPainter {
  final _values = const [0.42, 0.28, 0.18, 0.12];
  final _colors = const [AppTheme.accent, AppTheme.accentAlt, AppTheme.warning, AppTheme.textMuted];
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2 - 8;
    double startAngle = -pi / 2;
    for (int i = 0; i < _values.length; i++) {
      final sweep = _values[i] * 2 * pi;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), startAngle, sweep, false,
        Paint()..color = _colors[i]..style = PaintingStyle.stroke..strokeWidth = 22..strokeCap = StrokeCap.butt);
      startAngle += sweep;
    }
    canvas.drawCircle(center, radius - 22, Paint()..color = AppTheme.card..style = PaintingStyle.fill);
    final tp = TextPainter(textDirection: TextDirection.ltr);
    tp.text = const TextSpan(text: '1,284', style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w700));
    tp.layout();
    tp.paint(canvas, Offset(center.dx - tp.width / 2, center.dy - tp.height));
    tp.text = const TextSpan(text: 'total', style: TextStyle(color: AppTheme.textMuted, fontSize: 10));
    tp.layout();
    tp.paint(canvas, Offset(center.dx - tp.width / 2, center.dy + 2));
  }
  @override
  bool shouldRepaint(_) => false;
}

class _BarChartPainter extends CustomPainter {
  final _bars = const [
    ('Eng', 45, AppTheme.accent),
    ('Design', 28, Color(0xFF9B59B6)),
    ('Sales', 18, AppTheme.warning),
    ('HR', 12, AppTheme.danger),
    ('Ops', 22, AppTheme.accentAlt),
  ];
  @override
  void paint(Canvas canvas, Size size) {
    final bPad = 28.0, tPad = 10.0;
    final chartH = size.height - bPad - tPad;
    final maxVal = _bars.map((b) => b.$2).reduce(max).toDouble();
    final barW = (size.width / _bars.length) * 0.5;
    final tp = TextPainter(textDirection: TextDirection.ltr);

    for (int i = 0; i < _bars.length; i++) {
      final barH = (_bars[i].$2 / maxVal) * chartH;
      final sectionW = size.width / _bars.length;
      final x = i * sectionW + (sectionW - barW) / 2;
      final y = tPad + chartH - barH;

      // Bar
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, y, barW, barH), const Radius.circular(4)),
        Paint()..color = _bars[i].$3..style = PaintingStyle.fill);

      // Value on top
      tp.text = TextSpan(text: '${_bars[i].$2}', style: const TextStyle(color: AppTheme.textPrimary, fontSize: 11, fontWeight: FontWeight.w600));
      tp.layout();
      tp.paint(canvas, Offset(x + barW / 2 - tp.width / 2, y - 18));

      // Label below
      tp.text = TextSpan(text: _bars[i].$1, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11));
      tp.layout();
      tp.paint(canvas, Offset(x + barW / 2 - tp.width / 2, tPad + chartH + 8));
    }

    // Baseline
    canvas.drawLine(Offset(0, tPad + chartH), Offset(size.width, tPad + chartH),
      Paint()..color = AppTheme.cardBorder..strokeWidth = 1);
  }
  @override
  bool shouldRepaint(_) => false;
}

class _HBarChartPainter extends CustomPainter {
  final _bars = const [
    ('Sr. Engineer', 24, AppTheme.accent),
    ('Product Designer', 18, Color(0xFF9B59B6)),
    ('Data Analyst', 15, AppTheme.accentAlt),
    ('DevOps Engineer', 20, AppTheme.warning),
    ('UX Researcher', 12, AppTheme.danger),
  ];
  @override
  void paint(Canvas canvas, Size size) {
    final lPad = 110.0, rPad = 50.0;
    final maxVal = _bars.map((b) => b.$2).reduce(max).toDouble();
    final rowH = size.height / _bars.length;
    final barH = rowH * 0.4;
    final tp = TextPainter(textDirection: TextDirection.ltr);

    for (int i = 0; i < _bars.length; i++) {
      final barW = (_bars[i].$2 / maxVal) * (size.width - lPad - rPad);
      final y = i * rowH + (rowH - barH) / 2;

      // Label
      tp.text = TextSpan(text: _bars[i].$1, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11));
      tp.layout(maxWidth: lPad - 8);
      tp.paint(canvas, Offset(0, y + barH / 2 - tp.height / 2));

      // Bar
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(lPad, y, barW, barH), const Radius.circular(3)),
        Paint()..color = _bars[i].$3..style = PaintingStyle.fill);

      // Value
      tp.text = TextSpan(text: '${_bars[i].$2}d', style: TextStyle(color: _bars[i].$3, fontSize: 11, fontWeight: FontWeight.w700));
      tp.layout();
      tp.paint(canvas, Offset(lPad + barW + 6, y + barH / 2 - tp.height / 2));
    }
  }
  @override
  bool shouldRepaint(_) => false;
}
