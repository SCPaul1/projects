import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class JobsScreen extends StatefulWidget {
  const JobsScreen({super.key});
  @override
  State<JobsScreen> createState() => _JobsScreenState();
}

class _JobsScreenState extends State<JobsScreen> {
  String _filter = 'All';
  String _search = '';
  final _filters = ['All', 'Active', 'Paused', 'Closed', 'Draft'];

  final _jobs = const [
    _Job('Senior Software Engineer', 'Engineering', 'Remote', 'Full-time', 284, 'Active', '\$140–180K', 'High demand · 12 new today', 18),
    _Job('Product Designer', 'Design', 'New York, NY', 'Full-time', 147, 'Active', '\$110–140K', '3 in interview stage', 14),
    _Job('Data Analyst', 'Analytics', 'San Francisco, CA', 'Full-time', 98, 'Paused', '\$90–120K', 'Paused for budget review', 22),
    _Job('DevOps Engineer', 'Infrastructure', 'Remote', 'Full-time', 63, 'Active', '\$130–160K', '1 offer pending', 9),
    _Job('UX Researcher', 'Design', 'London, UK', 'Contract', 41, 'Active', '\$80–100K', 'Contract · 6 months', 7),
    _Job('Marketing Manager', 'Marketing', 'Chicago, IL', 'Full-time', 29, 'Draft', '\$85–110K', 'Pending approval from CFO', 0),
    _Job('Sales Executive', 'Sales', 'Austin, TX', 'Full-time', 72, 'Closed', '\$70–90K', 'Filled · hired 2 candidates', 31),
    _Job('ML Engineer', 'Engineering', 'Remote', 'Full-time', 118, 'Active', '\$150–190K', 'High priority · AI team', 21),
    _Job('Technical Writer', 'Product', 'Remote', 'Part-time', 34, 'Active', '\$55–75K', 'Part-time · flexible hours', 11),
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = _jobs.where((j) {
      final matchFilter = _filter == 'All' || j.status == _filter;
      final matchSearch = _search.isEmpty || j.title.toLowerCase().contains(_search.toLowerCase()) || j.dept.toLowerCase().contains(_search.toLowerCase());
      return matchFilter && matchSearch;
    }).toList();

    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Job Postings',
            subtitle: '24 active positions across 6 departments',
            action: _PostJobBtn(),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Summary chips
                  Row(children: [
                    _SummaryChip('24 Active', AppTheme.accentAlt),
                    const SizedBox(width: 10),
                    _SummaryChip('3 Paused', AppTheme.warning),
                    const SizedBox(width: 10),
                    _SummaryChip('2 Draft', AppTheme.textMuted),
                    const SizedBox(width: 10),
                    _SummaryChip('662 Total Applicants', AppTheme.accent),
                  ]),
                  const SizedBox(height: 20),
                  // Filter chips + search
                  Row(children: [
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: _filters.map((f) {
                            final active = _filter == f;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: InkWell(
                                onTap: () => setState(() => _filter = f),
                                borderRadius: BorderRadius.circular(20),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: active ? AppTheme.accent : AppTheme.card,
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(color: active ? AppTheme.accent : AppTheme.cardBorder),
                                  ),
                                  child: Text(f, style: TextStyle(color: active ? Colors.white : AppTheme.textSecondary, fontSize: 13, fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    SizedBox(
                      width: 220,
                      height: 38,
                      child: TextField(
                        onChanged: (v) => setState(() => _search = v),
                        style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
                        decoration: InputDecoration(
                          hintText: 'Search jobs…',
                          prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted, size: 16),
                          contentPadding: const EdgeInsets.symmetric(vertical: 0),
                          filled: true, fillColor: AppTheme.card,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.cardBorder)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.cardBorder)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.accent)),
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  Expanded(
                    child: SectionCard(
                      title: '${filtered.length} Jobs',
                      child: ListView.separated(
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const Divider(color: AppTheme.cardBorder, height: 1),
                        itemBuilder: (_, i) => _JobRow(job: filtered[i]),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final String label;
  final Color color;
  const _SummaryChip(this.label, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(0.25))),
    child: Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
  );
}

class _PostJobBtn extends StatelessWidget {
  const _PostJobBtn();
  @override
  Widget build(BuildContext context) => ElevatedButton.icon(
    onPressed: () {},
    icon: const Icon(Icons.add, size: 16),
    label: const Text('Post New Job'),
  );
}

class _JobRow extends StatelessWidget {
  final _Job job;
  const _JobRow({required this.job});

  Color get _statusColor {
    switch (job.status) {
      case 'Active': return AppTheme.accentAlt;
      case 'Paused': return AppTheme.warning;
      case 'Closed': return AppTheme.danger;
      default: return AppTheme.textMuted;
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 14),
    child: Row(children: [
      Container(
        width: 40, height: 40,
        decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.work_outline, color: AppTheme.accent, size: 20),
      ),
      const SizedBox(width: 14),
      Expanded(
        flex: 3,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(job.title, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Row(children: [
            const Icon(Icons.business_outlined, size: 12, color: AppTheme.textMuted),
            const SizedBox(width: 4),
            Text(job.dept, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
            const SizedBox(width: 12),
            const Icon(Icons.location_on_outlined, size: 12, color: AppTheme.textMuted),
            const SizedBox(width: 4),
            Text(job.location, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
          ]),
          const SizedBox(height: 3),
          Text(job.note, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        ]),
      ),
      _Chip(job.type, AppTheme.accent),
      const SizedBox(width: 16),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(job.salary, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 3),
          Text('${job.daysOld}d ago', style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
        ]),
      ),
      Expanded(
        child: Row(children: [
          const Icon(Icons.people_outline, size: 14, color: AppTheme.textMuted),
          const SizedBox(width: 6),
          Text('${job.applicants}', style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(width: 4),
          const Text('applicants', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
        ]),
      ),
      _Chip(job.status, _statusColor),
      const SizedBox(width: 16),
      IconButton(icon: const Icon(Icons.more_horiz, color: AppTheme.textMuted, size: 18), onPressed: () {}),
    ]),
  );
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip(this.label, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
    child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
  );
}

class _Job {
  final String title, dept, location, type, status, salary, note;
  final int applicants, daysOld;
  const _Job(this.title, this.dept, this.location, this.type, this.applicants, this.status, this.salary, this.note, this.daysOld);
}
