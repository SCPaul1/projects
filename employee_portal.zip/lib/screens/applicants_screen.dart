import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';

class ApplicantsScreen extends StatefulWidget {
  const ApplicantsScreen({super.key});
  @override
  State<ApplicantsScreen> createState() => _ApplicantsScreenState();
}

class _ApplicantsScreenState extends State<ApplicantsScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(title: 'Applicants', subtitle: '1,284 total applications · 89 in active interviews'),
          Container(
            color: AppTheme.surface,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: TabBar(
              controller: _tab,
              labelColor: AppTheme.accent,
              unselectedLabelColor: AppTheme.textSecondary,
              indicatorColor: AppTheme.accent,
              indicatorSize: TabBarIndicatorSize.label,
              tabs: const [Tab(text: 'Kanban Board'), Tab(text: 'List View')],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tab,
              children: [_PipelineView(), const _ListView()],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Kanban Board ──

class _PipelineView extends StatelessWidget {
  final _columns = const [
    _KanbanColumn('Applied', AppTheme.accent, [
      _Applicant('Maria Chen', 'Sr. Engineer', 'Applied 2h ago · Resume ✓', '🇺🇸', '94', 'New'),
      _Applicant('James Park', 'Product Designer', 'Applied 5h ago · Portfolio attached', '🇰🇷', '87', 'New'),
      _Applicant('Aisha Noor', 'Data Analyst', 'Applied 1d ago · Cover letter ✓', '🇬🇧', '82', 'New'),
      _Applicant('Priya Singh', 'ML Engineer', 'Applied 3h ago · GitHub attached', '🇮🇳', '91', 'Hot'),
    ]),
    _KanbanColumn('Screening', AppTheme.warning, [
    ]),
    _KanbanColumn('Interview', Color(0xFF9B59B6), [
      _Applicant('Jordan Lee', 'Data Analyst', 'Final round · Panel interview', '🇨🇦', '96', 'Hot'),
      _Applicant('Taylor Wu', 'Sr. Engineer', 'Technical done · System design next', '🇨🇳', '90', 'Hot'),
    ]),
    _KanbanColumn('Offer', AppTheme.accentAlt, [
      _Applicant('Chris Patel', 'Product Designer', 'Offer sent · \$115K · Awaiting reply', '🇮🇳', '93', 'Hot'),
    ]),
  ];

  _PipelineView({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _columns.map((col) => Expanded(
          child: Padding(
            padding: const EdgeInsets.only(right: 16),
            child: _KanbanColumnWidget(column: col),
          ),
        )).toList(),
      ),
    );
  }
}

class _KanbanColumnWidget extends StatelessWidget {
  final _KanbanColumn column;
  const _KanbanColumnWidget({required this.column});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: column.color.withOpacity(0.06),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: column.color.withOpacity(0.2)),
          ),
          child: Row(children: [
            Container(width: 8, height: 8, decoration: BoxDecoration(color: column.color, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text(column.title, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(color: column.color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: Text('${column.applicants.length}', style: TextStyle(color: column.color, fontSize: 11, fontWeight: FontWeight.w700)),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        ...column.applicants.map((a) => _KanbanCard(applicant: a, color: column.color)),
        const SizedBox(height: 8),
        InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              border: Border.all(color: AppTheme.cardBorder, style: BorderStyle.solid),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.add, color: AppTheme.textMuted, size: 14),
              SizedBox(width: 6),
              Text('Add applicant', style: TextStyle(color: AppTheme.textMuted, fontSize: 12)),
            ]),
          ),
        ),
      ],
    );
  }
}

class _KanbanCard extends StatelessWidget {
  final _Applicant applicant;
  final Color color;
  const _KanbanCard({required this.applicant, required this.color});

  Color get _tagColor => applicant.tag == 'Hot' ? AppTheme.danger : applicant.tag == 'In Review' ? AppTheme.warning : AppTheme.textMuted;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppTheme.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.cardBorder)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(applicant.flag, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(applicant.name, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
            Text(applicant.role, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(color: _tagColor.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
            child: Text(applicant.tag, style: TextStyle(color: _tagColor, fontSize: 10, fontWeight: FontWeight.w600)),
          ),
        ]),
        const SizedBox(height: 8),
        Text(applicant.status, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        const SizedBox(height: 10),
        Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
            child: Row(children: [
              const Icon(Icons.bolt, color: AppTheme.accent, size: 12),
              const SizedBox(width: 2),
              Text(applicant.score, style: const TextStyle(color: AppTheme.accent, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
          ),
          const Spacer(),
          _ActionBtn('Move', color),
          const SizedBox(width: 6),
          _ActionBtn('Reject', AppTheme.danger),
        ]),
      ]),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final Color color;
  const _ActionBtn(this.label, this.color);
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () {},
    borderRadius: BorderRadius.circular(6),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
    ),
  );
}

// ── List View ──

class _ListView extends StatelessWidget {
  const _ListView();

  static const _applicants = [
    _ListApplicant('Maria Chen', 'Sr. Engineer', 'Applied', '94', '🇺🇸', 'New', '2h ago', 'Resume + GitHub'),
    _ListApplicant('Alex Kim', 'UX Researcher', 'Screening', '88', '🇯🇵', 'In Review', '1d ago', 'Portfolio reviewed'),
    _ListApplicant('Jordan Lee', 'Data Analyst', 'Interview', '96', '🇨🇦', 'Hot', '4d ago', 'Final round'),
    _ListApplicant('Sam Rivera', 'DevOps Eng.', 'Screening', '85', '🇲🇽', 'In Review', '2d ago', 'Phone done'),
    _ListApplicant('Chris Patel', 'Product Designer', 'Offer', '93', '🇮🇳', 'Hot', '8d ago', 'Offer sent'),
    _ListApplicant('Aisha Noor', 'Data Analyst', 'Applied', '82', '🇬🇧', 'New', '1d ago', 'Cover letter ✓'),
    _ListApplicant('Priya Singh', 'ML Engineer', 'Applied', '91', '🇮🇳', 'Hot', '3h ago', 'GitHub attached'),
    _ListApplicant('Lena Müller', 'Sr. Engineer', 'Screening', '79', '🇩🇪', 'In Review', '3d ago', 'Take-home pending'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Container(
        decoration: BoxDecoration(color: AppTheme.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.cardBorder)),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              child: Row(children: const [
                Expanded(flex: 3, child: _TH('CANDIDATE')),
                Expanded(flex: 2, child: _TH('ROLE')),
                Expanded(child: _TH('STAGE')),
                Expanded(child: _TH('SCORE')),
                Expanded(child: _TH('TAG')),
                Expanded(flex: 2, child: _TH('NOTES')),
                SizedBox(width: 40),
              ]),
            ),
            const Divider(color: AppTheme.cardBorder, height: 1),
            Expanded(
              child: ListView.separated(
                itemCount: _applicants.length,
                separatorBuilder: (_, __) => const Divider(color: AppTheme.cardBorder, height: 1),
                itemBuilder: (_, i) => _ApplicantRow(a: _applicants[i]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TH extends StatelessWidget {
  final String text;
  const _TH(this.text);
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5));
}

class _ApplicantRow extends StatelessWidget {
  final _ListApplicant a;
  const _ApplicantRow({required this.a});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(children: [
        Expanded(flex: 3, child: Row(children: [
          Text(a.flag, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(a.name, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
            Text(a.appliedAt, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
          ]),
        ])),
        Expanded(flex: 2, child: Text(a.role, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13))),
        Expanded(child: _StageChip(a.stage)),
        Expanded(child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
          child: Row(children: [
            const Icon(Icons.bolt, color: AppTheme.accent, size: 12),
            const SizedBox(width: 2),
            Text(a.score, style: const TextStyle(color: AppTheme.accent, fontSize: 12, fontWeight: FontWeight.w700)),
          ]),
        )),
        Expanded(child: _TagChip(a.tag)),
        Expanded(flex: 2, child: Text(a.notes, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12))),
        IconButton(icon: const Icon(Icons.more_horiz, color: AppTheme.textMuted, size: 18), onPressed: () {}),
      ]),
    );
  }
}

class _StageChip extends StatelessWidget {
  final String stage;
  const _StageChip(this.stage);
  Color get _color {
    switch (stage) {
      case 'Applied': return AppTheme.accent;
      case 'Screening': return AppTheme.warning;
      case 'Interview': return const Color(0xFF9B59B6);
      case 'Offer': return AppTheme.accentAlt;
      default: return AppTheme.textMuted;
    }
  }
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: _color.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
    child: Text(stage, style: TextStyle(color: _color, fontSize: 11, fontWeight: FontWeight.w600)),
  );
}

class _TagChip extends StatelessWidget {
  final String tag;
  const _TagChip(this.tag);
  Color get _color => tag == 'Hot' ? AppTheme.danger : tag == 'In Review' ? AppTheme.warning : AppTheme.textSecondary;
  @override
  Widget build(BuildContext context) => Text(tag, style: TextStyle(color: _color, fontSize: 12, fontWeight: FontWeight.w500));
}

// ── Data models ──

class _KanbanColumn {
  final String title;
  final Color color;
  final List<_Applicant> applicants;
  const _KanbanColumn(this.title, this.color, this.applicants);
}

class _Applicant {
  final String name, role, status, flag, score, tag;
  const _Applicant(this.name, this.role, this.status, this.flag, this.score, this.tag);
}

class _ListApplicant {
  final String name, role, stage, score, flag, tag, appliedAt, notes;
  const _ListApplicant(this.name, this.role, this.stage, this.score, this.flag, this.tag, this.appliedAt, this.notes);
}
