import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Announcements',
            subtitle: 'Company news and updates',
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(24),
              itemCount: _announcements.length,
              itemBuilder: (context, index) {
                final a = _announcements[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _AnnouncementCard(announcement: a),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  final _Announcement announcement;

  const _AnnouncementCard({required this.announcement});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: announcement.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(announcement.icon, color: announcement.color, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      announcement.title,
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      announcement.date,
                      style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              if (announcement.isNew)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'New',
                    style: TextStyle(color: AppTheme.accent, fontSize: 10, fontWeight: FontWeight.w700),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            announcement.body,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 14,
              height: 1.5,
            ),
          ),
          if (announcement.author != null) ...[
            const SizedBox(height: 12),
            Text(
              '— ${announcement.author}',
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
        ],
      ),
    );
  }
}

class _Announcement {
  final String title;
  final String body;
  final String date;
  final String? author;
  final IconData icon;
  final Color color;
  final bool isNew;

  const _Announcement({
    required this.title,
    required this.body,
    required this.date,
    this.author,
    required this.icon,
    required this.color,
    this.isNew = false,
  });
}

const _announcements = [
  _Announcement(
    title: 'Office Holiday — Company Retreat',
    body: 'The office will be closed on March 29th for our annual company retreat. All team members are encouraged to join us at the Mountain View Campus for a day of workshops, team building, and planning for Q2. Lunch will be provided.',
    date: '21 Mar 2026',
    author: 'HR Team',
    icon: Icons.celebration,
    color: AppTheme.accent,
    isNew: true,
  ),
  _Announcement(
    title: 'Updated Health Benefits',
    body: 'We\'ve updated our health insurance options for 2026. New plans include expanded mental health coverage and lower deductibles. Please review your selection in the benefits portal by April 15th.',
    date: '18 Mar 2026',
    author: 'Benefits Team',
    icon: Icons.medical_services_outlined,
    color: AppTheme.accentAlt,
    isNew: true,
  ),
  _Announcement(
    title: 'IT System Maintenance',
    body: 'Scheduled maintenance will occur on Sunday, March 23rd from 2:00 AM to 4:00 AM PST. The employee portal and email may be briefly unavailable. Please save your work before this window.',
    date: '15 Mar 2026',
    icon: Icons.build_outlined,
    color: AppTheme.warning,
  ),
  _Announcement(
    title: 'Q1 All-Hands Meeting',
    body: 'Join us for the Q1 All-Hands on Friday, March 28th at 10 AM in the main auditorium. We\'ll share company highlights, product updates, and Q2 roadmap. Remote attendees can join via the usual link.',
    date: '10 Mar 2026',
    author: 'Executive Team',
    icon: Icons.groups_outlined,
    color: AppTheme.accent,
  ),
];
