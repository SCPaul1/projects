import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class LeaveScreen extends StatelessWidget {
  const LeaveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Leave',
            subtitle: 'Request and track your time off',
            action: _NewRequestButton(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Balance cards
                  Row(
                    children: [
                      Expanded(
                        child: _BalanceCard(
                          label: 'Vacation',
                          used: 7,
                          total: 25,
                          color: AppTheme.accent,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _BalanceCard(
                          label: 'Sick Leave',
                          used: 2,
                          total: 10,
                          color: AppTheme.accentAlt,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _BalanceCard(
                          label: 'Personal',
                          used: 0,
                          total: 5,
                          color: AppTheme.warning,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'My Leave Requests',
                    action: 'Request leave',
                    child: Table(
                      columnWidths: const {
                        0: FlexColumnWidth(2),
                        1: FlexColumnWidth(1.5),
                        2: FlexColumnWidth(1.5),
                        3: FlexColumnWidth(1),
                        4: FlexColumnWidth(1),
                      },
                      children: [
                        _tableHeader(),
                        ..._requests.map(_tableRow),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  TableRow _tableHeader() {
    const style = TextStyle(
      color: AppTheme.textMuted,
      fontSize: 11,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.5,
    );
    return TableRow(
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppTheme.cardBorder)),
      ),
      children: [
        Padding(padding: const EdgeInsets.only(bottom: 12), child: Text('TYPE', style: style)),
        Text('FROM', style: style),
        Text('TO', style: style),
        Text('DAYS', style: style),
        Text('STATUS', style: style),
      ],
    );
  }

  TableRow _tableRow(_LeaveRequest r) {
    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(
            r.type,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ),
        Text(r.from, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
        Text(r.to, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
        Text('${r.days}', style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
        _StatusChip(r.status),
      ],
    );
  }
}

class _NewRequestButton extends StatelessWidget {
  const _NewRequestButton();

  @override
  Widget build(BuildContext context) => ElevatedButton.icon(
        onPressed: () => _showRequestDialog(context),
        icon: const Icon(Icons.add, size: 16),
        label: const Text('Request Leave'),
        style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
      );
}

void _showRequestDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppTheme.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      title: const Text('Request Leave', style: TextStyle(color: AppTheme.textPrimary)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(labelText: 'Leave Type'),
            value: 'Vacation',
            items: ['Vacation', 'Sick Leave', 'Personal'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (_) {},
          ),
          const SizedBox(height: 16),
          TextField(
            decoration: const InputDecoration(labelText: 'From Date'),
            readOnly: true,
            onTap: () {},
          ),
          const SizedBox(height: 16),
          TextField(
            decoration: const InputDecoration(labelText: 'To Date'),
            readOnly: true,
            onTap: () {},
          ),
          const SizedBox(height: 16),
          TextField(
            decoration: const InputDecoration(labelText: 'Notes'),
            maxLines: 2,
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text('Submit')),
      ],
    ),
  );
}

class _BalanceCard extends StatelessWidget {
  final String label;
  final int used;
  final int total;
  final Color color;

  const _BalanceCard({
    required this.label,
    required this.used,
    required this.total,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final remaining = total - used;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Text(
            '$remaining',
            style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w800),
          ),
          Text(
            'of $total days remaining',
            style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: used / total,
            backgroundColor: AppTheme.cardBorder,
            valueColor: AlwaysStoppedAnimation(color),
            minHeight: 4,
            borderRadius: BorderRadius.circular(2),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip(this.status);

  Color get _color => status == 'Approved'
      ? AppTheme.accentAlt
      : status == 'Pending'
          ? AppTheme.warning
          : status == 'Rejected'
              ? AppTheme.danger
              : AppTheme.textMuted;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: _color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          status,
          style: TextStyle(color: _color, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      );
}

class _LeaveRequest {
  final String type, from, to, status;
  final int days;

  const _LeaveRequest(this.type, this.from, this.to, this.days, this.status);
}

const _requests = [
  _LeaveRequest('Vacation', '15 Mar 2026', '20 Mar 2026', 5, 'Approved'),
  _LeaveRequest('Sick Leave', '22 Mar 2026', '22 Mar 2026', 1, 'Pending'),
  _LeaveRequest('Personal', '10 Apr 2026', '12 Apr 2026', 3, 'Approved'),
  _LeaveRequest('Vacation', '02 Jan 2026', '06 Jan 2026', 4, 'Approved'),
];
