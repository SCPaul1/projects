import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/section_card.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'My Profile',
            subtitle: 'View and update your information',
            action: _EditButton(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  SectionCard(
                    title: 'Personal Information',
                    child: Column(
                      children: [
                        _ProfileField(label: 'Full Name', value: 'Saroj Paul'),
                        _ProfileField(label: 'Employee ID', value: 'EMP-2024-0847'),
                        _ProfileField(label: 'Email', value: 'saroj.paul@company.com'),
                        _ProfileField(label: 'Phone', value: '7044261792'),
                        _ProfileField(label: 'Date of Birth', value: '15 Jan 1992'),
                        _ProfileField(label: 'Address', value: 'Ghola, Sodepur, Panihati, Kolkata, West Bengal, India'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Work Information',
                    child: Column(
                      children: [
                        _ProfileField(label: 'Department', value: 'Engineering'),
                        _ProfileField(label: 'Job Title', value: 'Software Engineer'),
                        _ProfileField(label: 'Manager', value: 'Sarah Chen'),
                        _ProfileField(label: 'Start Date', value: '3 Mar 2022'),
                        _ProfileField(label: 'Work Location', value: 'San Francisco HQ'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  SectionCard(
                    title: 'Emergency Contact',
                    child: Column(
                      children: [
                        _ProfileField(label: 'Name', value: 'Jane Johnson'),
                        _ProfileField(label: 'Relationship', value: 'Spouse'),
                        _ProfileField(label: 'Phone', value: '+1 (555) 987-6543'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EditButton extends StatelessWidget {
  const _EditButton();

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
        onPressed: () {},
        icon: const Icon(Icons.edit_outlined, size: 16),
        label: const Text('Edit Profile'),
        style: OutlinedButton.styleFrom(
          foregroundColor: AppTheme.accent,
          side: const BorderSide(color: AppTheme.accent),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      );
}

class _ProfileField extends StatelessWidget {
  final String label;
  final String value;

  const _ProfileField({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              label,
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}
