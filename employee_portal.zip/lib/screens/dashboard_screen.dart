import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/page_header.dart';
import '../widgets/stat_card.dart';
import '../widgets/section_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          const PageHeader(
            title: 'Dashboard',
            subtitle: 'Saturday, 21 March 2026',
            action: _RequestLeaveButton(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Welcome card
                  _WelcomeCard(name: 'Saroj Paul'),
                  const SizedBox(height: 24),
                  // Stats row
                  GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1.6,
                    children: const [
                      StatCard(label: 'Leave Balance', value: '18', delta: '0', positive: true, icon: Icons.calendar_today_outlined, color: AppTheme.accent),
                      StatCard(label: 'Pending Requests', value: '1', delta: '0', positive: true, icon: Icons.pending_outlined, color: AppTheme.warning),
                      StatCard(label: 'Documents', value: '5', delta: '0', positive: true, icon: Icons.description_outlined, color: AppTheme.accentAlt),
                      StatCard(label: 'Announcements', value: '3', delta: '+1', positive: true, icon: Icons.campaign_outlined, color: AppTheme.danger),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 3,
                        child: SectionCard(
                          title: 'Recent Announcements',
                          action: 'View all',
                          child: Column(
                            children: _announcements.map((a) => _AnnouncementRow(announcement: a)).toList(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 2,
                        child: SectionCard(
                          title: 'Upcoming',
                          child: Column(
                            children: _upcoming.map((u) => _UpcomingRow(item: u)).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 2,
                        child: SectionCard(
                          title: 'Quick Actions',
                          child: Wrap(
                            spacing: 12,
                            runSpacing: 12,
                            children: [
                              const _QuickAction(icon: Icons.edit_calendar, label: 'Request Leave', color: AppTheme.accent),
                              const _QuickAction(icon: Icons.download, label: 'Payslips', color: AppTheme.accentAlt),
                              const _QuickAction(icon: Icons.edit_outlined, label: 'Update Profile', color: AppTheme.warning),
                              const _QuickAction(icon: Icons.people, label: 'Directory', color: AppTheme.danger),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 3,
                        child: SectionCard(
                          title: 'My Leave Requests',
                          action: 'View all',
                          child: Column(
                            children: _leaveRequests.map((l) => _LeaveRequestRow(request: l)).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  final String name;

  const _WelcomeCard({required this.name});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.accent.withOpacity(0.15),
            AppTheme.accentAlt.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.cardBorder),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppTheme.accent.withOpacity(0.3),
            child: Text(
              name.split(' ').map((s) => s[0]).join(),
              style: const TextStyle(color: AppTheme.accent, fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome back, $name',
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Software Engineer · Engineering',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RequestLeaveButton extends StatelessWidget {
  const _RequestLeaveButton();

  @override
  Widget build(BuildContext context) => ElevatedButton.icon(
        onPressed: () {},
        icon: const Icon(Icons.add, size: 16),
        label: const Text('Request Leave'),
        style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
      );
}

class _AnnouncementRow extends StatelessWidget {
  final _Announcement announcement;

  const _AnnouncementRow({required this.announcement});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: announcement.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(announcement.icon, color: announcement.color, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    announcement.title,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    announcement.body,
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    announcement.date,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class _UpcomingRow extends StatelessWidget {
  final _Upcoming item;

  const _UpcomingRow({required this.item});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.cardBorder),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    item.day,
                    style: const TextStyle(
                      color: AppTheme.accent,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    item.month,
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 9),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    item.subtitle,
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {},
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LeaveRequestRow extends StatelessWidget {
  final _LeaveRequest request;

  const _LeaveRequestRow({required this.request});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    request.type,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '${request.from} – ${request.to}',
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
                  ),
                ],
              ),
            ),
                            _StatusChip(request.status),
          ],
        ),
      );
}

class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip(this.status);

  Color get _color => status == 'Approved'
      ? AppTheme.accentAlt
      : status == 'Pending'
          ? AppTheme.warning
          : AppTheme.textMuted;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: _color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          status,
          style: TextStyle(color: _color, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      );
}

// Data models

class _Announcement {
  final String title, body, date;
  final IconData icon;
  final Color color;

  const _Announcement(this.title, this.body, this.date, this.icon, this.color);
}

class _Upcoming {
  final String day, month, title, subtitle;

  const _Upcoming(this.day, this.month, this.title, this.subtitle);
}

class _LeaveRequest {
  final String type, from, to, status;

  const _LeaveRequest(this.type, this.from, this.to, this.status);
}

const _announcements = [
  _Announcement('Office Holiday', 'Office closed Mar 29 for company retreat.', '2 hours ago', Icons.celebration, AppTheme.accent),
  _Announcement('New Benefits', 'Health insurance options updated. Review your selection.', '1 day ago', Icons.medical_services_outlined, AppTheme.accentAlt),
  _Announcement('IT Maintenance', 'System maintenance scheduled for Sunday 2–4 AM.', '2 days ago', Icons.build_outlined, AppTheme.warning),
];

const _upcoming = [
  _Upcoming('29', 'Mar', 'Company Retreat', 'Office closed'),
  _Upcoming('01', 'Apr', 'Pay Day', 'March salary'),
  _Upcoming('15', 'Apr', 'Leave Starts', 'Vacation (5 days)'),
];

const _leaveRequests = [
  _LeaveRequest('Vacation', 'Mar 15', 'Mar 20', 'Approved'),
  _LeaveRequest('Sick Leave', 'Mar 22', 'Mar 22', 'Pending'),
  _LeaveRequest('Personal', 'Apr 10', 'Apr 12', 'Approved'),
];
