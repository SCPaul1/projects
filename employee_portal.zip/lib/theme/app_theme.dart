import 'package:flutter/material.dart';

class AppTheme {
  static const Color bg = Color(0xFF0A0D14);
  static const Color surface = Color(0xFF111520);
  static const Color card = Color(0xFF161C2D);
  static const Color cardBorder = Color(0xFF232B3E);
  static const Color accent = Color(0xFF4F6EF7);
  static const Color accentGlow = Color(0x334F6EF7);
  static const Color accentAlt = Color(0xFF00D4AA);
  static const Color danger = Color(0xFFFF4D6A);
  static const Color warning = Color(0xFFFFA940);
  static const Color textPrimary = Color(0xFFEEF0F8);
  static const Color textSecondary = Color(0xFF7B85A3);
  static const Color textMuted = Color(0xFF3E4A6A);

  static ThemeData get darkTheme => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        fontFamily: 'Inter',
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: accentAlt,
          surface: surface,
          error: danger,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: surface,
          elevation: 0,
          iconTheme: IconThemeData(color: textPrimary),
          titleTextStyle: TextStyle(
            color: textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w600,
            letterSpacing: -0.3,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: card,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: cardBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: cardBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: accent, width: 1.5),
          ),
          hintStyle: const TextStyle(color: textMuted, fontSize: 14),
          labelStyle: const TextStyle(color: textSecondary),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 15,
              letterSpacing: 0.2,
            ),
          ),
        ),
      );
}
